* Tell where to find Metro by setting METRO_HOME
    - For example 'export Metro_HOME=c:/metro'
* To run type: 'ant client run'

